# raul_app

Aplicacion Android en Flutter con Clean Architecture, Material 3 y modo oscuro.

## Estado actual

Base arquitectonica completa y funcional. Todavia no tiene funcionalidades de negocio
porque aun no se definio que hace la app. La base ya incluye:

- Tema claro y oscuro con Material 3, persistido entre sesiones
- Navegacion con GoRouter
- Estado con Riverpod
- Almacenamiento local con Hive y SharedPreferences
- Componentes reutilizables y animaciones
- Diseno responsive

## Estructura

```
lib/
  core/        configuracion, constantes, errores, resultado, router
  features/    cada funcionalidad, aislada y autocontenida
  widgets/     componentes reutilizables de UI
  services/    preferencias, almacenamiento, logging
  models/      modelos de datos
  database/    inicializacion y acceso a Hive
  theme/       colores, tipografia, temas, controlador de modo oscuro
  utils/       extensiones, validadores, helpers responsive
  main.dart
```

## Como generar la carpeta android

Este proyecto se escribio sin ejecutar `flutter create`, asi que la carpeta `android/`
se genera una sola vez con:

```
flutter create --platforms=android --org cl.raulisaac --project-name raul_app .
```

Ese comando NO borra el codigo existente en `lib/`.

## Como correr y compilar

```
flutter pub get
flutter run
flutter build apk --release
```

El APK queda en `build/app/outputs/flutter-apk/app-release.apk`.
