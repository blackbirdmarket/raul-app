import 'dart:ui' show PlatformDispatcher;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'core/config/app_config.dart';
import 'core/constants/app_constants.dart';
import 'core/router/app_router.dart';
import 'database/hive_setup.dart';
import 'services/logger_service.dart';
import 'services/preferences_service.dart';
import 'theme/app_theme.dart';
import 'theme/theme_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // El orden importa: la configuracion debe existir antes que cualquier cosa
  // que pueda escribir un log.
  AppConfig.initialize(
    environment: kReleaseMode ? Environment.production : Environment.development,
  );

  _setUpErrorHandling();

  await HiveSetup.initialize();
  final prefs = await SharedPreferences.getInstance();

  runApp(
    ProviderScope(
      overrides: <Override>[
        sharedPreferencesProvider.overrideWithValue(prefs),
      ],
      child: const App(),
    ),
  );
}

/// Captura los errores que Flutter no maneja, para que queden registrados en
/// vez de perderse en la consola.
void _setUpErrorHandling() {
  FlutterError.onError = (details) {
    FlutterError.presentError(details);
    LoggerService.error(
      details.exceptionAsString(),
      tag: 'FLUTTER',
      error: details.exception,
      stackTrace: details.stack,
    );
  };

  PlatformDispatcher.instance.onError = (error, stackTrace) {
    LoggerService.error(
      'Error no capturado.',
      tag: 'PLATFORM',
      error: error,
      stackTrace: stackTrace,
    );
    return true;
  };
}

class App extends ConsumerWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(appRouterProvider);
    final themeMode = ref.watch(themeControllerProvider);

    return MaterialApp.router(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      routerConfig: router,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: themeMode,
    );
  }
}
