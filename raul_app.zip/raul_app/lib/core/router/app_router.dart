import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/planning/presentation/pages/agenda_page.dart';
import '../../features/planning/presentation/pages/day_page.dart';
import '../../features/settings/presentation/pages/settings_page.dart';
import '../../widgets/app_empty_state.dart';
import '../../widgets/app_shell.dart';
import '../config/app_config.dart';
import 'routes.dart';

final _rootNavigatorKey = GlobalKey<NavigatorState>();

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: AppRoutes.day,
    debugLogDiagnostics: AppConfig.instance.isDevelopment,
    routes: <RouteBase>[
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) =>
            AppShell(navigationShell: navigationShell),
        branches: <StatefulShellBranch>[
          StatefulShellBranch(
            routes: <RouteBase>[
              GoRoute(
                path: AppRoutes.day,
                name: AppRoutes.dayName,
                builder: (context, state) => const DayPage(),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: <RouteBase>[
              GoRoute(
                path: AppRoutes.agenda,
                name: AppRoutes.agendaName,
                builder: (context, state) => const AgendaPage(),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: <RouteBase>[
              GoRoute(
                path: AppRoutes.settings,
                name: AppRoutes.settingsName,
                builder: (context, state) => const SettingsPage(),
              ),
            ],
          ),
        ],
      ),
    ],
    errorBuilder: (context, state) => Scaffold(
      body: AppEmptyState(
        title: 'Pagina no encontrada',
        message: 'La ruta "${state.uri}" no existe.',
        icon: Icons.explore_off_outlined,
        actionLabel: 'Volver al inicio',
        onAction: () => context.go(AppRoutes.day),
      ),
    ),
  );
});
