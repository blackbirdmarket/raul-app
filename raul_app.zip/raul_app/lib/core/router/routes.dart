/// Rutas de la aplicacion.
///
/// Se declaran como constantes para que navegar sea `context.go(AppRoutes.day)`
/// y no una cadena escrita a mano con un error de tipeo que el compilador
/// jamas detectaria.
class AppRoutes {
  const AppRoutes._();

  /// El dia en su riel de horas. Pantalla de entrada.
  static const String day = '/';

  /// Todo lo que viene, agrupado por dia.
  static const String agenda = '/agenda';

  static const String settings = '/ajustes';

  static const String dayName = 'day';
  static const String agendaName = 'agenda';
  static const String settingsName = 'settings';
}
