/// Rutas de la aplicacion.
///
/// Se declaran como constantes para que navegar sea `context.go(AppRoutes.home)`
/// y no una cadena escrita a mano que puede tener un error de tipeo que el
/// compilador jamas detectaria.
class AppRoutes {
  const AppRoutes._();

  static const String home = '/';
  static const String settings = '/settings';

  /// Nombres para navegacion por nombre, util cuando una ruta lleva parametros.
  static const String homeName = 'home';
  static const String settingsName = 'settings';
}
