/// Rutas de la aplicacion.
///
/// Cada ruta de primer nivel es un area del sistema. Hoy solo existe
/// planificacion; las que vengan se suman aqui y en la barra inferior.
class AppRoutes {
  const AppRoutes._();

  /// Area de planificacion: el dia y la agenda.
  static const String planning = '/';

  /// Area de finanzas: movimientos y cuentas.
  static const String finance = '/finanzas';

  static const String settings = '/ajustes';

  static const String planningName = 'planning';
  static const String financeName = 'finance';
  static const String settingsName = 'settings';
}
