/// Constantes globales de la aplicacion.
///
/// Todo valor que se use en mas de un lugar vive aqui, nunca escrito
/// directamente dentro de un widget. Asi un cambio se hace una sola vez.
class AppConstants {
  const AppConstants._();

  /// Nombre visible de la aplicacion.
  static const String appName = 'Raul App';

  /// Version funcional, independiente de la version del build.
  static const String appVersion = '0.1.0';

  // --- Espaciado ---
  // Escala de 4 puntos. Usar siempre estos valores en vez de numeros sueltos.
  static const double spaceXs = 4;
  static const double spaceSm = 8;
  static const double spaceMd = 16;
  static const double spaceLg = 24;
  static const double spaceXl = 32;
  static const double spaceXxl = 48;

  // --- Radios de borde ---
  static const double radiusSm = 8;
  static const double radiusMd = 12;
  static const double radiusLg = 20;
  static const double radiusFull = 999;

  // --- Duraciones de animacion ---
  static const Duration durationFast = Duration(milliseconds: 150);
  static const Duration durationNormal = Duration(milliseconds: 250);
  static const Duration durationSlow = Duration(milliseconds: 400);

  // --- Puntos de quiebre responsive ---
  static const double breakpointMobile = 600;
  static const double breakpointTablet = 900;
  static const double breakpointDesktop = 1200;

  /// Ancho maximo del contenido en pantallas grandes, para que el texto
  /// no quede en lineas incomodamente largas.
  static const double maxContentWidth = 720;
}
