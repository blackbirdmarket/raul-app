import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

/// Estructura persistente que envuelve las areas del sistema.
///
/// La barra de abajo lista areas, no pantallas. Hoy solo hay planificacion y
/// ajustes; cuando aparezcan finanzas, salud o lo que sea, se suman aqui sin
/// tocar nada de lo que ya funciona.
class AppShell extends StatelessWidget {
  const AppShell({required this.navigationShell, super.key});

  final StatefulNavigationShell navigationShell;

  static const List<NavigationDestination> _destinations =
      <NavigationDestination>[
    NavigationDestination(
      icon: Icon(Icons.calendar_today_outlined),
      selectedIcon: Icon(Icons.calendar_today_rounded),
      label: 'Planning',
    ),
    NavigationDestination(
      icon: Icon(Icons.tune_outlined),
      selectedIcon: Icon(Icons.tune_rounded),
      label: 'Ajustes',
    ),
  ];

  void _onDestinationSelected(int index) {
    // `initialLocation: true` al volver a tocar el area activa la devuelve a
    // su raiz, que es lo que uno espera de una barra de navegacion.
    navigationShell.goBranch(
      index,
      initialLocation: index == navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: navigationShell,
      bottomNavigationBar: NavigationBar(
        selectedIndex: navigationShell.currentIndex,
        onDestinationSelected: _onDestinationSelected,
        destinations: _destinations,
      ),
    );
  }
}
