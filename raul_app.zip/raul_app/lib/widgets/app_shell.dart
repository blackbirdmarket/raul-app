import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

/// Estructura persistente que envuelve las pantallas principales.
///
/// La barra de navegacion vive aqui y no dentro de cada pantalla, para que no
/// se reconstruya ni se anime al cambiar de pestana. El `navigationShell`
/// conserva el estado de cada rama, asi el usuario vuelve a una pestana y la
/// encuentra donde la dejo.
class AppShell extends StatelessWidget {
  const AppShell({required this.navigationShell, super.key});

  final StatefulNavigationShell navigationShell;

  static const List<NavigationDestination> _destinations =
      <NavigationDestination>[
    NavigationDestination(
      icon: Icon(Icons.home_outlined),
      selectedIcon: Icon(Icons.home_rounded),
      label: 'Inicio',
    ),
    NavigationDestination(
      icon: Icon(Icons.settings_outlined),
      selectedIcon: Icon(Icons.settings_rounded),
      label: 'Ajustes',
    ),
  ];

  void _onDestinationSelected(int index) {
    // `initialLocation: true` cuando se vuelve a tocar la pestana activa
    // devuelve esa rama a su raiz, que es el comportamiento que el usuario
    // espera de una barra de navegacion.
    navigationShell.goBranch(
      index,
      initialLocation: index == navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: navigationShell,
      bottomNavigationBar: NavigationBar(
        selectedIndex: navigationShell.currentIndex,
        onDestinationSelected: _onDestinationSelected,
        destinations: _destinations,
      ),
    );
  }
}
