import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

/// Estructura persistente que envuelve las pantallas principales.
///
/// La barra de navegacion vive aqui y no dentro de cada pantalla, para que no
/// se reconstruya ni se anime al cambiar de pestana. El `navigationShell`
/// conserva el estado de cada rama: se vuelve a una pestana y esta donde
/// quedo, incluida la posicion del scroll.
class AppShell extends StatelessWidget {
  const AppShell({required this.navigationShell, super.key});

  final StatefulNavigationShell navigationShell;

  static const List<NavigationDestination> _destinations =
      <NavigationDestination>[
    NavigationDestination(
      icon: Icon(Icons.today_outlined),
      selectedIcon: Icon(Icons.today_rounded),
      label: 'Hoy',
    ),
    NavigationDestination(
      icon: Icon(Icons.event_note_outlined),
      selectedIcon: Icon(Icons.event_note_rounded),
      label: 'Agenda',
    ),
    NavigationDestination(
      icon: Icon(Icons.tune_outlined),
      selectedIcon: Icon(Icons.tune_rounded),
      label: 'Ajustes',
    ),
  ];

  void _onDestinationSelected(int index) {
    // `initialLocation: true` al volver a tocar la pestana activa devuelve esa
    // rama a su raiz, que es lo que uno espera de una barra de navegacion.
    navigationShell.goBranch(
      index,
      initialLocation: index == navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: navigationShell,
      bottomNavigationBar: NavigationBar(
        selectedIndex: navigationShell.currentIndex,
        onDestinationSelected: _onDestinationSelected,
        destinations: _destinations,
      ),
    );
  }
}
