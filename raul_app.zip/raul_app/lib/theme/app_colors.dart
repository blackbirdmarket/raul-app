import 'package:flutter/material.dart';

/// Paleta base de la aplicacion.
///
/// Material 3 genera los esquemas claro y oscuro completos a partir del color
/// semilla, garantizando contraste accesible sin tener que ajustar cada tono a
/// mano. Los colores semanticos se definen aparte porque su significado no
/// debe depender del branding.
class AppColors {
  const AppColors._();

  /// Color semilla del que se derivan ambos esquemas.
  static const Color seed = Color(0xFF4F46E5);

  // --- Colores semanticos ---
  static const Color success = Color(0xFF16A34A);
  static const Color warning = Color(0xFFD97706);
  static const Color danger = Color(0xFFDC2626);
  static const Color info = Color(0xFF0284C7);

  static ColorScheme lightScheme() => ColorScheme.fromSeed(
        seedColor: seed,
      );

  static ColorScheme darkScheme() => ColorScheme.fromSeed(
        seedColor: seed,
        brightness: Brightness.dark,
      );
}
