import 'package:flutter/material.dart';

/// Paleta de la aplicacion.
///
/// Los esquemas se derivan de Material 3 pero con las superficies fijadas a
/// mano. La razon: `fromSeed` tine los grises con el color de acento, y para
/// una agenda que se mira muchas veces al dia ese tinte cansa. Los fondos
/// quedan neutros y el color se reserva para lo que de verdad importa.
class AppColors {
  const AppColors._();

  static const Color accent = Color(0xFF7C6CF6);
  static const Color accentSoft = Color(0xFFA48FFF);

  // --- Colores semanticos ---
  static const Color success = Color(0xFF34D399);
  static const Color warning = Color(0xFFFBBF24);
  static const Color danger = Color(0xFFF87171);

  /// Acentos para distinguir bloques de un vistazo.
  ///
  /// Elegidos con luminosidad pareja para que ninguno domine visualmente
  /// sobre los demas dentro del riel.
  static const List<Color> blockAccents = <Color>[
    Color(0xFF7C6CF6), // violeta
    Color(0xFF38BDF8), // celeste
    Color(0xFF34D399), // verde
    Color(0xFFFBBF24), // ambar
    Color(0xFFF472B6), // rosa
    Color(0xFFFB923C), // naranja
  ];

  static Color blockAccent(int index) =>
      blockAccents[index.abs() % blockAccents.length];

  static ColorScheme darkScheme() =>
      ColorScheme.fromSeed(seedColor: accent, brightness: Brightness.dark)
          .copyWith(
        primary: accentSoft,
        onPrimary: const Color(0xFF16112E),
        surface: const Color(0xFF08080C),
        onSurface: const Color(0xFFF3F3F6),
        onSurfaceVariant: const Color(0xFF9494A2),
        surfaceContainerLowest: const Color(0xFF06060A),
        surfaceContainerLow: const Color(0xFF101018),
        surfaceContainer: const Color(0xFF14141D),
        surfaceContainerHigh: const Color(0xFF1A1A24),
        surfaceContainerHighest: const Color(0xFF22222E),
        outline: const Color(0xFF3A3A48),
        outlineVariant: const Color(0xFF262632),
        error: danger,
      );

  static ColorScheme lightScheme() =>
      ColorScheme.fromSeed(seedColor: accent).copyWith(
        primary: const Color(0xFF5B4BD6),
        surface: const Color(0xFFFBFBFD),
        onSurface: const Color(0xFF16161C),
        onSurfaceVariant: const Color(0xFF6B6B78),
        surfaceContainerLowest: Colors.white,
        surfaceContainerLow: const Color(0xFFF5F5F8),
        surfaceContainer: const Color(0xFFF0F0F4),
        surfaceContainerHigh: const Color(0xFFEAEAF0),
        surfaceContainerHighest: const Color(0xFFE3E3EB),
        outline: const Color(0xFFB8B8C4),
        outlineVariant: const Color(0xFFE0E0E8),
        error: const Color(0xFFDC2626),
      );
}
