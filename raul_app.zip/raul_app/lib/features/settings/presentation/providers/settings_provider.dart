import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/failure.dart';
import '../../../../core/result/result.dart';
import '../../../../database/hive_setup.dart';
import '../../../../services/logger_service.dart';
import '../../../../services/preferences_service.dart';
import '../../../../services/storage_service.dart';

final settingsControllerProvider =
    Provider<SettingsController>(SettingsController.new);

/// Acciones de la pantalla de ajustes que tocan datos.
///
/// Vive fuera del widget para que la pantalla se ocupe solo de mostrar, y para
/// que estas operaciones se puedan probar sin construir interfaz.
class SettingsController {
  const SettingsController(this._ref);

  final Ref _ref;

  /// Borra todos los datos locales y la configuracion.
  ///
  /// Es una operacion destructiva, asi que devuelve un `Result`: la pantalla
  /// debe poder avisar si algo no se pudo borrar en vez de asumir exito.
  Future<Result<void>> resetAllData() async {
    try {
      final storage = _ref.read(storageServiceProvider);
      await storage.clear(box: HiveBoxes.app);
      await storage.clear(box: HiveBoxes.cache);
      await _ref.read(preferencesServiceProvider).clear();

      LoggerService.info('Datos locales restablecidos.', tag: 'SETTINGS');
      return const Result<void>.success(null);
    } catch (error, stackTrace) {
      LoggerService.error(
        'Fallo al restablecer los datos.',
        tag: 'SETTINGS',
        error: error,
        stackTrace: stackTrace,
      );
      return const Result<void>.failure(
        StorageFailure('No se pudieron borrar todos los datos.'),
      );
    }
  }
}
