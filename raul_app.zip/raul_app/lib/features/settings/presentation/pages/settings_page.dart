import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../theme/theme_controller.dart';
import '../../../../utils/extensions.dart';
import '../../../../widgets/app_card.dart';
import '../../../../widgets/fade_in.dart';
import '../../../planning/presentation/providers/agenda_providers.dart';
import '../providers/settings_provider.dart';

/// Pantalla de ajustes.
class SettingsPage extends ConsumerWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeControllerProvider);
    final total = ref.watch(agendaProvider).length;

    return Scaffold(
      appBar: AppBar(title: const Text('Ajustes')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(AppConstants.spaceMd),
          children: <Widget>[
            const FadeIn(child: _SectionTitle('Apariencia')),
            const SizedBox(height: AppConstants.spaceSm),
            FadeIn(
              delay: const Duration(milliseconds: 60),
              child: AppCard(
                padding: const EdgeInsets.symmetric(
                  vertical: AppConstants.spaceSm,
                ),
                child: Column(
                  children: <Widget>[
                    for (final mode in ThemeMode.values)
                      ListTile(
                        onTap: () => ref
                            .read(themeControllerProvider.notifier)
                            .setThemeMode(mode),
                        title: Text(_labelFor(mode)),
                        subtitle: Text(
                          _descriptionFor(mode),
                          style: context.texts.bodySmall?.copyWith(
                            color: context.colors.onSurfaceVariant,
                          ),
                        ),
                        trailing: AnimatedOpacity(
                          duration: AppConstants.durationFast,
                          opacity: themeMode == mode ? 1 : 0,
                          child: Icon(
                            Icons.check_circle_rounded,
                            color: context.colors.primary,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: AppConstants.spaceLg),
            const FadeIn(
              delay: Duration(milliseconds: 120),
              child: _SectionTitle('Avisos'),
            ),
            const SizedBox(height: AppConstants.spaceSm),
            FadeIn(
              delay: const Duration(milliseconds: 160),
              child: AppCard(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Icon(
                      Icons.info_outline_rounded,
                      size: 20,
                      color: context.colors.onSurfaceVariant,
                    ),
                    const SizedBox(width: AppConstants.spaceSm),
                    Expanded(
                      child: Text(
                        'Ya puedes elegir el tipo de aviso de cada tarea y de '
                        'cada paso. Las alarmas del sistema se activan en la '
                        'proxima version.',
                        style: context.texts.bodySmall?.copyWith(
                          color: context.colors.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: AppConstants.spaceLg),
            const FadeIn(
              delay: Duration(milliseconds: 200),
              child: _SectionTitle('Datos'),
            ),
            const SizedBox(height: AppConstants.spaceSm),
            FadeIn(
              delay: const Duration(milliseconds: 240),
              child: AppCard(
                padding: EdgeInsets.zero,
                child: Column(
                  children: <Widget>[
                    ListTile(
                      leading: const Icon(Icons.inventory_2_outlined),
                      title: const Text('En tu agenda'),
                      subtitle: Text(
                        total == 1
                            ? '1 elemento guardado'
                            : '$total elementos guardados',
                      ),
                    ),
                    Divider(height: 1, color: context.colors.outlineVariant),
                    ListTile(
                      leading: Icon(
                        Icons.delete_outline_rounded,
                        color: context.colors.error,
                      ),
                      title: const Text('Restablecer la aplicacion'),
                      subtitle: const Text(
                        'Borra toda tu agenda de este telefono.',
                      ),
                      onTap: () => _confirmReset(context, ref),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: AppConstants.spaceLg),
            const FadeIn(
              delay: Duration(milliseconds: 280),
              child: _SectionTitle('Acerca de'),
            ),
            const SizedBox(height: AppConstants.spaceSm),
            FadeIn(
              delay: const Duration(milliseconds: 320),
              child: AppCard(
                padding: EdgeInsets.zero,
                child: ListTile(
                  leading: const Icon(Icons.auto_awesome_rounded),
                  title: const Text(AppConstants.appName),
                  subtitle: const Text('Version ${AppConstants.appVersion}'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmReset(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Restablecer la aplicacion'),
        content: const Text(
          'Se borrara toda tu agenda de este telefono. '
          'Esta accion no se puede deshacer.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Borrar todo'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    final result = await ref.read(settingsControllerProvider).resetAllData();

    // El usuario pudo salir de la pantalla mientras se borraban los datos.
    if (!context.mounted) return;

    result.fold(
      onSuccess: (_) => context.showMessage('Aplicacion restablecida.'),
      onFailure: (failure) => context.showError(failure.message),
    );
  }

  static String _labelFor(ThemeMode mode) => switch (mode) {
        ThemeMode.system => 'Automatico',
        ThemeMode.light => 'Claro',
        ThemeMode.dark => 'Oscuro',
      };

  static String _descriptionFor(ThemeMode mode) => switch (mode) {
        ThemeMode.system => 'Sigue la configuracion del telefono.',
        ThemeMode.light => 'Siempre con fondo claro.',
        ThemeMode.dark => 'Siempre con fondo oscuro.',
      };
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.title);

  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: AppConstants.spaceXs),
      child: Text(
        title.toUpperCase(),
        style: context.texts.labelMedium?.copyWith(
          color: context.colors.primary,
          letterSpacing: 1,
        ),
      ),
    );
  }
}
