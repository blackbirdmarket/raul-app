import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../theme/theme_controller.dart';
import '../../../../utils/extensions.dart';
import '../../../../utils/responsive.dart';
import '../../../../widgets/app_card.dart';
import '../../../../widgets/fade_in.dart';

/// Pantalla principal.
///
/// Hoy muestra el estado de la base tecnica. Cuando se definan las
/// funcionalidades reales, este archivo se reemplaza sin tocar nada mas:
/// el resto de la arquitectura no depende de lo que haya aqui.
class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  static const List<_Capability> _capabilities = <_Capability>[
    _Capability(
      icon: Icons.architecture_rounded,
      title: 'Clean Architecture',
      description: 'Cada funcionalidad aislada, sin codigo duplicado.',
    ),
    _Capability(
      icon: Icons.palette_outlined,
      title: 'Material 3 y modo oscuro',
      description: 'Tema claro y oscuro, recordado entre sesiones.',
    ),
    _Capability(
      icon: Icons.storage_outlined,
      title: 'Almacenamiento local',
      description: 'Hive para datos y SharedPreferences para configuracion.',
    ),
    _Capability(
      icon: Icons.route_outlined,
      title: 'Navegacion con estado',
      description: 'Cada pestana conserva donde la dejaste.',
    ),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeControllerProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.appName),
        actions: <Widget>[
          IconButton(
            onPressed: () =>
                ref.read(themeControllerProvider.notifier).toggle(context),
            icon: Icon(
              switch (themeMode) {
                ThemeMode.dark => Icons.light_mode_outlined,
                ThemeMode.light => Icons.dark_mode_outlined,
                ThemeMode.system => Icons.brightness_auto_outlined,
              },
            ),
            tooltip: 'Cambiar tema',
          ),
          const SizedBox(width: AppConstants.spaceXs),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.symmetric(
            horizontal: context.responsive<double>(
              mobile: AppConstants.spaceMd,
              tablet: AppConstants.spaceLg,
            ),
            vertical: AppConstants.spaceMd,
          ),
          children: <Widget>[
            const FadeIn(child: _Header()),
            const SizedBox(height: AppConstants.spaceLg),
            for (var i = 0; i < _capabilities.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: AppConstants.spaceSm),
                child: FadeIn(
                  delay: Duration(milliseconds: 60 * (i + 1)),
                  child: _CapabilityCard(capability: _capabilities[i]),
                ),
              ),
            const SizedBox(height: AppConstants.spaceLg),
            FadeIn(
              delay: const Duration(milliseconds: 360),
              child: Text(
                'Base lista. Falta definir que hace la aplicacion.',
                textAlign: TextAlign.center,
                style: context.texts.bodySmall?.copyWith(
                  color: context.colors.onSurfaceVariant,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text('Hola', style: context.texts.bodyLarge?.copyWith(
              color: context.colors.onSurfaceVariant,
            )),
        const SizedBox(height: AppConstants.spaceXs),
        Text(
          'Todo funcionando',
          style: context.texts.headlineMedium,
        ),
      ],
    );
  }
}

class _CapabilityCard extends StatelessWidget {
  const _CapabilityCard({required this.capability});

  final _Capability capability;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Row(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(AppConstants.spaceSm + 2),
            decoration: BoxDecoration(
              color: context.colors.primaryContainer,
              borderRadius: BorderRadius.circular(AppConstants.radiusSm),
            ),
            child: Icon(
              capability.icon,
              color: context.colors.onPrimaryContainer,
              size: 22,
            ),
          ),
          const SizedBox(width: AppConstants.spaceMd),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(capability.title, style: context.texts.titleMedium),
                const SizedBox(height: 2),
                Text(
                  capability.description,
                  style: context.texts.bodySmall?.copyWith(
                    color: context.colors.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Capability {
  const _Capability({
    required this.icon,
    required this.title,
    required this.description,
  });

  final IconData icon;
  final String title;
  final String description;
}
