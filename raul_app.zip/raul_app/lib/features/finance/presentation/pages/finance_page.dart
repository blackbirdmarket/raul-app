import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../utils/extensions.dart';
import '../providers/finance_providers.dart';
import '../widgets/accounts_view.dart';
import '../widgets/movement_editor_sheet.dart';
import '../widgets/movements_view.dart';

/// Area de finanzas.
///
/// Sigue la misma forma que Planning: el nombre del area arriba a la
/// izquierda, el cambio de vista a la derecha, y todo lo demas dentro. Que las
/// dos areas se comporten igual es lo que hace que la app se sienta una sola
/// cosa y no dos apps pegadas.
class FinancePage extends ConsumerWidget {
  const FinancePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final view = ref.watch(financeViewProvider);

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(
          children: <Widget>[
            const _AreaBar(),
            Expanded(
              child: IndexedStack(
                index: view.index,
                children: const <Widget>[
                  MovementsView(),
                  AccountsView(),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => showMovementEditor(context),
        child: const Icon(Icons.add_rounded),
      ),
    );
  }
}

class _AreaBar extends ConsumerWidget {
  const _AreaBar();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final view = ref.watch(financeViewProvider);

    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppConstants.spaceMd,
        AppConstants.spaceSm,
        AppConstants.spaceSm,
        AppConstants.spaceXs,
      ),
      child: Row(
        children: <Widget>[
          Text(
            'FINANZAS',
            style: context.texts.labelSmall?.copyWith(
              color: context.colors.onSurfaceVariant,
              fontSize: 10,
              letterSpacing: 1.6,
            ),
          ),
          const Spacer(),
          _ViewSwitch(
            value: view,
            onChanged: (next) =>
                ref.read(financeViewProvider.notifier).select(next),
          ),
        ],
      ),
    );
  }
}

class _ViewSwitch extends StatelessWidget {
  const _ViewSwitch({required this.value, required this.onChanged});

  final FinanceView value;
  final ValueChanged<FinanceView> onChanged;

  @override
  Widget build(BuildContext context) {
    final scheme = context.colors;

    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: scheme.surfaceContainer,
        borderRadius: BorderRadius.circular(AppConstants.radiusFull),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          for (final option in FinanceView.values)
            GestureDetector(
              onTap: () => onChanged(option),
              behavior: HitTestBehavior.opaque,
              child: AnimatedContainer(
                duration: AppConstants.durationFast,
                curve: Curves.easeOut,
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: option == value ? scheme.primary : Colors.transparent,
                  borderRadius: BorderRadius.circular(AppConstants.radiusFull),
                ),
                child: Text(
                  option.label,
                  style: context.texts.labelLarge?.copyWith(
                    fontSize: 13,
                    color: option == value
                        ? scheme.onPrimary
                        : scheme.onSurfaceVariant,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
