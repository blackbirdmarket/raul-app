import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../utils/extensions.dart';
import '../providers/agenda_providers.dart';
import '../widgets/agenda_view.dart';
import '../widgets/day_view.dart';
import '../widgets/entry_editor_sheet.dart';

/// Area de planificacion.
///
/// Es la primera area del sistema, no la aplicacion entera. Por eso el dia y
/// la agenda conviven aqui dentro con un cambio de vista, en vez de ocupar dos
/// pestanas: la barra de abajo se reserva para las areas que vengan despues.
class PlanningPage extends ConsumerWidget {
  const PlanningPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final view = ref.watch(planningViewProvider);
    final day = ref.watch(selectedDayProvider);

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(
          children: <Widget>[
            const _AreaBar(),
            Expanded(
              // IndexedStack y no un switch: asi cada vista conserva su scroll
              // al ir y volver, que es justo lo que uno espera al alternar.
              child: IndexedStack(
                index: view.index,
                children: const <Widget>[
                  DayView(),
                  AgendaView(),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => showEntryEditor(context, day: day),
        child: const Icon(Icons.add_rounded),
      ),
    );
  }
}

/// Nombre del area y selector de vista.
class _AreaBar extends ConsumerWidget {
  const _AreaBar();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final view = ref.watch(planningViewProvider);

    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppConstants.spaceMd,
        AppConstants.spaceSm,
        AppConstants.spaceSm,
        AppConstants.spaceXs,
      ),
      child: Row(
        children: <Widget>[
          Text(
            'PLANNING',
            style: context.texts.labelSmall?.copyWith(
              color: context.colors.onSurfaceVariant,
              fontSize: 10,
              letterSpacing: 1.6,
            ),
          ),
          const Spacer(),
          _ViewSwitch(
            value: view,
            onChanged: (next) =>
                ref.read(planningViewProvider.notifier).select(next),
          ),
        ],
      ),
    );
  }
}

/// Selector compacto entre las dos vistas.
class _ViewSwitch extends StatelessWidget {
  const _ViewSwitch({required this.value, required this.onChanged});

  final PlanningView value;
  final ValueChanged<PlanningView> onChanged;

  @override
  Widget build(BuildContext context) {
    final scheme = context.colors;

    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: scheme.surfaceContainer,
        borderRadius: BorderRadius.circular(AppConstants.radiusFull),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          for (final option in PlanningView.values)
            GestureDetector(
              onTap: () => onChanged(option),
              behavior: HitTestBehavior.opaque,
              child: AnimatedContainer(
                duration: AppConstants.durationFast,
                curve: Curves.easeOut,
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: option == value ? scheme.primary : Colors.transparent,
                  borderRadius: BorderRadius.circular(AppConstants.radiusFull),
                ),
                child: Text(
                  option.label,
                  style: context.texts.labelLarge?.copyWith(
                    fontSize: 13,
                    color: option == value
                        ? scheme.onPrimary
                        : scheme.onSurfaceVariant,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
