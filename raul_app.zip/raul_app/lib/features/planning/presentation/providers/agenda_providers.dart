import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../models/agenda_entry.dart';
import '../../../../models/sub_task.dart';
import '../../data/agenda_repository.dart';

/// Las dos maneras de mirar lo planificado.
///
/// El dia sirve para ejecutar, la agenda para planificar. Son la misma
/// informacion con dos lecturas, por eso viven en la misma area y no en
/// pestanas separadas: la barra de abajo queda libre para las otras areas
/// que vengan despues.
enum PlanningView {
  day('Dia'),
  agenda('Agenda');

  const PlanningView(this.label);

  final String label;
}

final planningViewProvider =
    NotifierProvider<PlanningViewController, PlanningView>(
  PlanningViewController.new,
);

class PlanningViewController extends Notifier<PlanningView> {
  @override
  PlanningView build() => PlanningView.day;

  void select(PlanningView view) => state = view;
}

/// Dia que se esta mirando. Siempre normalizado a medianoche.
final selectedDayProvider =
    NotifierProvider<SelectedDayController, DateTime>(SelectedDayController.new);

class SelectedDayController extends Notifier<DateTime> {
  @override
  DateTime build() => today();

  static DateTime today() {
    final now = DateTime.now();
    return DateTime(now.year, now.month, now.day);
  }

  void select(DateTime day) {
    state = DateTime(day.year, day.month, day.day);
  }

  void goToToday() => state = today();

  void shiftDays(int days) {
    final next = state.add(Duration(days: days));
    state = DateTime(next.year, next.month, next.day);
  }
}

/// Dias plegados en la vista de agenda.
///
/// Vive en un provider y no dentro del widget para que se conserve al ir a
/// otra pestana y volver: plegar media agenda y perderlo al parpadear seria
/// exasperante.
final collapsedDaysProvider =
    NotifierProvider<CollapsedDaysController, Set<DateTime>>(
  CollapsedDaysController.new,
);

class CollapsedDaysController extends Notifier<Set<DateTime>> {
  @override
  Set<DateTime> build() => <DateTime>{};

  void toggle(DateTime day) {
    final next = <DateTime>{...state};
    if (!next.remove(day)) next.add(day);
    state = next;
  }

  bool isCollapsed(DateTime day) => state.contains(day);
}

/// Hasta cuando se generan las repeticiones por adelantado.
///
/// Tres meses alcanzan para planificar de verdad sin llenar el telefono de
/// elementos que quiza nunca se miren.
const int _horizonDays = 90;

/// Toda la agenda en memoria, ordenada por hora.
///
/// Se mantiene la lista completa cargada porque una agenda personal cabe de
/// sobra en memoria, y tenerla entera permite que las vistas de dia, semana y
/// resumen se deriven sin volver a tocar el disco.
final agendaProvider =
    NotifierProvider<AgendaController, List<AgendaEntry>>(AgendaController.new);

class AgendaController extends Notifier<List<AgendaEntry>> {
  @override
  List<AgendaEntry> build() {
    final stored = ref.watch(agendaRepositoryProvider).loadAll();
    final pending = _missingOccurrences(stored);

    if (pending.isNotEmpty) {
      // Se persiste despues de la primera pintura: la agenda tiene que
      // aparecer al instante, y guardar noventa dias de repeticiones puede
      // tardar lo suficiente como para notarse.
      Future<void>.microtask(() async {
        for (final entry in pending) {
          await _repository.save(entry);
        }
      });
    }

    return <AgendaEntry>[...stored, ...pending]
      ..sort((a, b) => a.start.compareTo(b.start));
  }

  AgendaRepository get _repository => ref.read(agendaRepositoryProvider);

  /// Completa las series hasta el horizonte.
  ///
  /// Se ejecuta en cada arranque, asi una repeticion diaria creada hace meses
  /// sigue apareciendo sin que nadie tenga que renovarla a mano.
  List<AgendaEntry> _missingOccurrences(List<AgendaEntry> stored) {
    final bySeries = <String, List<AgendaEntry>>{};
    for (final entry in stored) {
      final series = entry.seriesId;
      if (series == null || !entry.recurrence.isActive) continue;
      bySeries.putIfAbsent(series, () => <AgendaEntry>[]).add(entry);
    }

    final horizon = DateTime.now().add(const Duration(days: _horizonDays));
    final generated = <AgendaEntry>[];

    for (final occurrences in bySeries.values) {
      final last = occurrences.reduce(
        (a, b) => a.start.isAfter(b.start) ? a : b,
      );

      var cursor = last.recurrence.nextAfter(last.start);
      var guard = 0;

      while (cursor != null && !cursor.isAfter(horizon) && guard < 400) {
        generated.add(
          last.occurrenceAt(
            cursor,
            newId: newEntryId(),
            series: last.seriesId!,
          ),
        );
        cursor = last.recurrence.nextAfter(cursor);
        guard++;
      }
    }

    return generated;
  }

  /// Crea o reemplaza un elemento. El estado se actualiza al tiro y la
  /// escritura ocurre despues, para que la interfaz no espere al disco.
  Future<void> upsert(AgendaEntry entry) async {
    final next = <AgendaEntry>[
      ...state.where((e) => e.id != entry.id),
      entry,
    ]..sort((a, b) => a.start.compareTo(b.start));

    state = next;
    await _repository.save(entry);
  }

  /// Crea la serie completa a partir de su primera ocurrencia.
  Future<void> createSeries(AgendaEntry first) async {
    if (!first.recurrence.isActive) {
      await upsert(first);
      return;
    }

    final series = first.seriesId ?? newEntryId();
    final occurrences = <AgendaEntry>[
      first.occurrenceAt(first.start, newId: first.id, series: series),
    ];

    final horizon = DateTime.now().add(const Duration(days: _horizonDays));
    var cursor = first.recurrence.nextAfter(first.start);
    var guard = 0;

    while (cursor != null && !cursor.isAfter(horizon) && guard < 400) {
      occurrences.add(
        first.occurrenceAt(cursor, newId: newEntryId(), series: series),
      );
      cursor = first.recurrence.nextAfter(cursor);
      guard++;
    }

    state = <AgendaEntry>[...state, ...occurrences]
      ..sort((a, b) => a.start.compareTo(b.start));

    for (final entry in occurrences) {
      await _repository.save(entry);
    }
  }

  Future<void> remove(String id) async {
    state = state.where((e) => e.id != id).toList();
    await _repository.remove(id);
  }

  /// Borra todas las ocurrencias de una repeticion.
  Future<void> removeSeries(String seriesId) async {
    final doomed = state.where((e) => e.seriesId == seriesId).toList();
    state = state.where((e) => e.seriesId != seriesId).toList();

    for (final entry in doomed) {
      await _repository.remove(entry.id);
    }
  }

  /// Busca por id sin lanzar si no esta.
  ///
  /// Se escribe a mano en vez de usar `firstWhere` porque cualquier accion
  /// puede llegar tarde: si el elemento se borro entre el toque y el
  /// procesamiento, lo correcto es no hacer nada, no reventar.
  AgendaEntry? _find(String id) {
    for (final entry in state) {
      if (entry.id == id) return entry;
    }
    return null;
  }

  /// Marca o desmarca una tarea rapida.
  Future<void> toggleTask(String id) async {
    final task = _find(id);
    if (task is! QuickTask) return;
    await upsert(task.copyWith(done: !task.done));
  }

  /// Marca o desmarca un paso dentro de un bloque.
  Future<void> toggleSubTask(String blockId, String subTaskId) async {
    final block = _find(blockId);
    if (block is! TimeBlock) return;

    final updated = block.subtasks
        .map((s) => s.id == subTaskId ? s.copyWith(done: !s.done) : s)
        .toList();

    await upsert(block.copyWith(subtasks: updated));
  }

  /// Agrega un paso a un bloque existente, sin abrir el editor completo.
  Future<void> addSubTask(String blockId, String title) async {
    final block = _find(blockId);
    if (block is! TimeBlock) return;

    final subtask = SubTask(id: newEntryId(), title: title.trim());
    await upsert(
      block.copyWith(subtasks: <SubTask>[...block.subtasks, subtask]),
    );
  }

  /// Mueve un pendiente atrasado al dia de hoy, conservando su hora.
  Future<void> moveToToday(String id) async {
    final entry = _find(id);
    if (entry == null) return;

    final today = SelectedDayController.today();
    final newStart = DateTime(
      today.year,
      today.month,
      today.day,
      entry.start.hour,
      entry.start.minute,
    );

    switch (entry) {
      case QuickTask():
        await upsert(entry.copyWith(start: newStart));
      case TimeBlock():
        await upsert(
          entry.copyWith(start: newStart, end: newStart.add(entry.duration)),
        );
    }
  }
}

/// Elementos de un dia concreto, ya ordenados.
final entriesForDayProvider =
    Provider.family<List<AgendaEntry>, DateTime>((ref, day) {
  final target = DateTime(day.year, day.month, day.day);
  return ref.watch(agendaProvider).where((e) => e.day == target).toList();
});

/// Lo que quedo pendiente en dias que ya pasaron.
///
/// Antes esto simplemente desaparecia: la agenda miraba de hoy en adelante y
/// una tarea sin marcar del martes se esfumaba en silencio.
final overdueProvider = Provider<List<AgendaEntry>>((ref) {
  final today = SelectedDayController.today();
  return ref
      .watch(agendaProvider)
      .where((e) => e.day.isBefore(today) && !e.isComplete)
      .toList()
      .reversed
      .toList();
});

/// Resumen de carga de un dia, para pintar la tira semanal y las barras de
/// progreso sin recorrer la agenda entera dentro de un widget.
class DayLoad {
  const DayLoad({
    required this.total,
    required this.done,
    required this.hasAlarm,
  });

  final int total;
  final int done;
  final bool hasAlarm;

  bool get isEmpty => total == 0;
  bool get isComplete => total > 0 && done == total;
  double get progress => total == 0 ? 0 : done / total;
  int get percent => (progress * 100).round();
}

final dayLoadProvider = Provider.family<DayLoad, DateTime>((ref, day) {
  final entries = ref.watch(entriesForDayProvider(day));
  return DayLoad(
    total: entries.length,
    done: entries.where((e) => e.isComplete).length,
    hasAlarm: entries.any((e) => e.hasReminder),
  );
});
