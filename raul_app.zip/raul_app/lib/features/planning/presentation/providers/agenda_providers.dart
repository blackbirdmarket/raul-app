import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../models/agenda_entry.dart';
import '../../../../models/sub_task.dart';
import '../../data/agenda_repository.dart';

/// Las dos maneras de mirar lo planificado.
///
/// El dia sirve para ejecutar, la agenda para planificar. Son la misma
/// informacion con dos lecturas, por eso viven en la misma area y no en
/// pestanas separadas: la barra de abajo queda libre para las otras areas
/// que vengan despues.
enum PlanningView {
  day('Dia'),
  agenda('Agenda');

  const PlanningView(this.label);

  final String label;
}

final planningViewProvider =
    NotifierProvider<PlanningViewController, PlanningView>(
  PlanningViewController.new,
);

class PlanningViewController extends Notifier<PlanningView> {
  @override
  PlanningView build() => PlanningView.day;

  void select(PlanningView view) => state = view;
}

/// Dia que se esta mirando. Siempre normalizado a medianoche.
final selectedDayProvider =
    NotifierProvider<SelectedDayController, DateTime>(SelectedDayController.new);

class SelectedDayController extends Notifier<DateTime> {
  @override
  DateTime build() => _today();

  static DateTime _today() {
    final now = DateTime.now();
    return DateTime(now.year, now.month, now.day);
  }

  void select(DateTime day) {
    state = DateTime(day.year, day.month, day.day);
  }

  void goToToday() => state = _today();

  void shiftDays(int days) {
    final next = state.add(Duration(days: days));
    state = DateTime(next.year, next.month, next.day);
  }
}

/// Toda la agenda en memoria, ordenada por hora.
///
/// Se mantiene la lista completa cargada porque una agenda personal cabe de
/// sobra en memoria, y tenerla entera permite que las vistas de dia, semana y
/// resumen se deriven sin volver a tocar el disco.
final agendaProvider =
    NotifierProvider<AgendaController, List<AgendaEntry>>(AgendaController.new);

class AgendaController extends Notifier<List<AgendaEntry>> {
  @override
  List<AgendaEntry> build() => ref.watch(agendaRepositoryProvider).loadAll();

  AgendaRepository get _repository => ref.read(agendaRepositoryProvider);

  /// Crea o reemplaza un elemento. El estado se actualiza al tiro y la
  /// escritura ocurre despues, para que la interfaz no espere al disco.
  Future<void> upsert(AgendaEntry entry) async {
    final next = <AgendaEntry>[
      ...state.where((e) => e.id != entry.id),
      entry,
    ]..sort((a, b) => a.start.compareTo(b.start));

    state = next;
    await _repository.save(entry);
  }

  Future<void> remove(String id) async {
    state = state.where((e) => e.id != id).toList();
    await _repository.remove(id);
  }

  /// Marca o desmarca una tarea rapida.
  Future<void> toggleTask(String id) async {
    final task = state.firstWhere(
      (e) => e.id == id,
      orElse: () => throw StateError('No existe la tarea $id'),
    );
    if (task is! QuickTask) return;
    await upsert(task.copyWith(done: !task.done));
  }

  /// Marca o desmarca un paso dentro de un bloque.
  Future<void> toggleSubTask(String blockId, String subTaskId) async {
    final block = state.firstWhere(
      (e) => e.id == blockId,
      orElse: () => throw StateError('No existe el bloque $blockId'),
    );
    if (block is! TimeBlock) return;

    final updated = block.subtasks
        .map((s) => s.id == subTaskId ? s.copyWith(done: !s.done) : s)
        .toList();

    await upsert(block.copyWith(subtasks: updated));
  }

  /// Agrega un paso a un bloque existente, sin abrir el editor completo.
  Future<void> addSubTask(String blockId, String title) async {
    final block = state.firstWhere(
      (e) => e.id == blockId,
      orElse: () => throw StateError('No existe el bloque $blockId'),
    );
    if (block is! TimeBlock) return;

    final subtask = SubTask(id: newEntryId(), title: title.trim());
    await upsert(
      block.copyWith(subtasks: <SubTask>[...block.subtasks, subtask]),
    );
  }
}

/// Elementos de un dia concreto, ya ordenados.
final entriesForDayProvider =
    Provider.family<List<AgendaEntry>, DateTime>((ref, day) {
  final target = DateTime(day.year, day.month, day.day);
  return ref
      .watch(agendaProvider)
      .where((e) => e.day == target)
      .toList();
});

/// Resumen de carga de un dia, para pintar la tira semanal sin recorrer
/// la agenda entera dentro de un widget.
class DayLoad {
  const DayLoad({
    required this.total,
    required this.done,
    required this.hasAlarm,
  });

  final int total;
  final int done;
  final bool hasAlarm;

  bool get isEmpty => total == 0;
  bool get isComplete => total > 0 && done == total;
  double get progress => total == 0 ? 0 : done / total;
}

final dayLoadProvider = Provider.family<DayLoad, DateTime>((ref, day) {
  final entries = ref.watch(entriesForDayProvider(day));
  return DayLoad(
    total: entries.length,
    done: entries.where((e) => e.isComplete).length,
    hasAlarm: entries.any((e) => e.hasReminder),
  );
});

/// Lo que todavia queda por hacer hoy, de aqui en adelante.
final pendingTodayProvider = Provider<List<AgendaEntry>>((ref) {
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  return ref
      .watch(entriesForDayProvider(today))
      .where((e) => !e.isComplete)
      .toList();
});
