import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../models/agenda_entry.dart';
import '../../../../models/alert_mode.dart';
import '../../../../utils/date_format.dart';
import '../../../../utils/extensions.dart';
import '../../../../widgets/check_circle.dart';
import '../providers/agenda_providers.dart';

/// Una tarea rapida dentro del riel.
///
/// Se dibuja como una pildora baja, deliberadamente mas liviana que un bloque:
/// la jerarquia visual tiene que decir "esto se despacha en un momento" sin
/// que haya que leer nada.
class QuickTaskTile extends ConsumerWidget {
  const QuickTaskTile({
    required this.task,
    this.onTap,
    super.key,
  });

  final QuickTask task;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scheme = context.colors;

    return Material(
      color: scheme.surfaceContainerLow,
      borderRadius: BorderRadius.circular(AppConstants.radiusMd),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: scheme.outlineVariant),
            borderRadius: BorderRadius.circular(AppConstants.radiusMd),
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: AppConstants.spaceSm,
            vertical: 6,
          ),
          child: Row(
            children: <Widget>[
              CheckCircle(
                checked: task.done,
                size: 22,
                onTap: () {
                  HapticFeedback.selectionClick();
                  ref.read(agendaProvider.notifier).toggleTask(task.id);
                },
              ),
              const SizedBox(width: AppConstants.spaceSm),
              Expanded(
                child: AnimatedDefaultTextStyle(
                  duration: AppConstants.durationFast,
                  style: context.texts.bodyLarge!.copyWith(
                    color: task.done
                        ? scheme.onSurfaceVariant
                        : scheme.onSurface,
                    decoration:
                        task.done ? TextDecoration.lineThrough : null,
                    decorationColor: scheme.onSurfaceVariant,
                    fontWeight: FontWeight.w500,
                  ),
                  child: Text(
                    task.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
              if (task.isRecurring) ...<Widget>[
                const SizedBox(width: 6),
                Icon(
                  Icons.repeat_rounded,
                  size: 15,
                  color: scheme.onSurfaceVariant,
                ),
              ],
              if (task.alert != AlertMode.none) ...<Widget>[
                const SizedBox(width: AppConstants.spaceSm),
                Icon(
                  task.alert == AlertMode.alarm
                      ? Icons.alarm_rounded
                      : Icons.notifications_none_rounded,
                  size: 16,
                  color: scheme.onSurfaceVariant,
                ),
              ],
              const SizedBox(width: AppConstants.spaceSm),
              Text(
                DateNames.time(task.start),
                style: context.texts.labelMedium?.copyWith(
                  color: scheme.onSurfaceVariant,
                  letterSpacing: 0,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
