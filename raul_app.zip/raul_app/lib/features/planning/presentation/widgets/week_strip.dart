import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../utils/date_format.dart';
import '../../../../utils/extensions.dart';
import '../providers/agenda_providers.dart';

/// Tira horizontal con los siete dias de la semana.
///
/// Es el mando de navegacion principal: siempre visible, siempre en el mismo
/// lugar. Cada dia muestra cuanta carga tiene, para que se note de un vistazo
/// donde esta el dia apretado antes siquiera de abrirlo.
class WeekStrip extends ConsumerWidget {
  const WeekStrip({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selected = ref.watch(selectedDayProvider);
    final monday = DateNames.startOfWeek(selected);
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    return SizedBox(
      height: 78,
      child: Row(
        children: <Widget>[
          for (var i = 0; i < 7; i++)
            Expanded(
              child: _DayCell(
                date: monday.add(Duration(days: i)),
                isSelected: monday.add(Duration(days: i)) == selected,
                isToday: monday.add(Duration(days: i)) == today,
              ),
            ),
        ],
      ),
    );
  }
}

class _DayCell extends ConsumerWidget {
  const _DayCell({
    required this.date,
    required this.isSelected,
    required this.isToday,
  });

  final DateTime date;
  final bool isSelected;
  final bool isToday;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final load = ref.watch(dayLoadProvider(date));
    final scheme = context.colors;

    final Color background = isSelected
        ? scheme.primary
        : isToday
            ? scheme.primary.withValues(alpha: 0.12)
            : Colors.transparent;

    final Color foreground = isSelected
        ? scheme.onPrimary
        : isToday
            ? scheme.primary
            : scheme.onSurface;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => ref.read(selectedDayProvider.notifier).select(date),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            DateNames.weekdayShort(date),
            style: context.texts.labelSmall?.copyWith(
              color: isSelected ? scheme.primary : scheme.onSurfaceVariant,
              fontSize: 10,
            ),
          ),
          const SizedBox(height: 6),
          AnimatedContainer(
            duration: AppConstants.durationFast,
            curve: Curves.easeOut,
            width: 38,
            height: 38,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: background,
              borderRadius: BorderRadius.circular(AppConstants.radiusMd),
            ),
            child: Text(
              '${date.day}',
              style: context.texts.titleMedium?.copyWith(
                color: foreground,
                fontWeight: isSelected || isToday
                    ? FontWeight.w700
                    : FontWeight.w500,
              ),
            ),
          ),
          const SizedBox(height: 6),
          _LoadDot(load: load, isSelected: isSelected),
        ],
      ),
    );
  }
}

/// Punto bajo cada dia: vacio si no hay nada, relleno segun lo completado.
class _LoadDot extends StatelessWidget {
  const _LoadDot({required this.load, required this.isSelected});

  final DayLoad load;
  final bool isSelected;

  @override
  Widget build(BuildContext context) {
    if (load.isEmpty) {
      return const SizedBox(height: 5);
    }

    final scheme = context.colors;
    final color = load.isComplete ? scheme.onSurfaceVariant : scheme.primary;

    return Container(
      width: load.isComplete ? 5 : 5 + (load.total.clamp(1, 4) * 3).toDouble(),
      height: 5,
      decoration: BoxDecoration(
        color: isSelected ? scheme.primary : color,
        borderRadius: BorderRadius.circular(AppConstants.radiusFull),
      ),
    );
  }
}
