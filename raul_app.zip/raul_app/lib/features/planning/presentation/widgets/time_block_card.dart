import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../models/agenda_entry.dart';
import '../../../../models/alert_mode.dart';
import '../../../../models/sub_task.dart';
import '../../../../theme/app_colors.dart';
import '../../../../utils/date_format.dart';
import '../../../../utils/extensions.dart';
import '../../../../widgets/check_circle.dart';
import '../../../../widgets/progress_ring.dart';
import '../providers/agenda_providers.dart';

/// Un bloque de tiempo con sus pasos dentro.
///
/// El alto viene impuesto por el riel: un bloque de dos horas ocupa el doble
/// que uno de una. Por eso los pasos se muestran solo si sobra espacio, y el
/// contenido va recortado — un bloque corto se ve compacto en vez de
/// desbordarse sobre el siguiente.
class TimeBlockCard extends ConsumerWidget {
  const TimeBlockCard({
    required this.block,
    this.height,
    this.onTap,
    this.showSubtasks = true,
    super.key,
  });

  final TimeBlock block;

  /// Alto fijo cuando se dibuja dentro del riel. En una lista normal va null
  /// y la tarjeta toma el alto que necesite.
  final double? height;

  final VoidCallback? onTap;
  final bool showSubtasks;

  /// Los pasos, ocupando el espacio que sobre.
  ///
  /// `Flexible` solo es valido cuando el alto esta acotado. En el riel lo esta
  /// (lo impone la duracion) y sirve para recortar lo que no quepa; en la
  /// agenda el alto es libre y usar `Flexible` ahi rompe el layout con
  /// restricciones infinitas. Esa distincion es justamente lo que dejaba la
  /// agenda inutilizable.
  Widget _subtasksSlot(Color accent) {
    final content = Padding(
      padding: const EdgeInsets.only(top: 10),
      child: _SubtaskList(block: block, accent: accent),
    );
    return height == null ? content : Flexible(child: content);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scheme = context.colors;
    final accent = AppColors.blockAccent(block.colorIndex);
    final complete = block.isComplete;

    return Material(
      color: scheme.surfaceContainerLow,
      borderRadius: BorderRadius.circular(AppConstants.radiusLg),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          height: height,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppConstants.radiusLg),
            border: Border.all(
              color: complete
                  ? scheme.outlineVariant
                  : accent.withValues(alpha: 0.35),
            ),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: <Color>[
                accent.withValues(alpha: complete ? 0.04 : 0.13),
                accent.withValues(alpha: 0.02),
              ],
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              // Barra de color a la izquierda: identifica el bloque de lejos.
              Container(width: 4, color: complete ? scheme.outline : accent),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      _Header(block: block, accent: accent),
                      if (showSubtasks && block.subtasks.isNotEmpty)
                        _subtasksSlot(accent),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.block, required this.accent});

  final TimeBlock block;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    final scheme = context.colors;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(
                block.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: context.texts.titleMedium?.copyWith(
                  color: block.isComplete
                      ? scheme.onSurfaceVariant
                      : scheme.onSurface,
                  decoration:
                      block.isComplete ? TextDecoration.lineThrough : null,
                  decorationColor: scheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 2),
              Row(
                children: <Widget>[
                  Text(
                    '${DateNames.time(block.start)} - '
                    '${DateNames.time(block.end)}',
                    style: context.texts.labelMedium?.copyWith(
                      color: scheme.onSurfaceVariant,
                      letterSpacing: 0,
                    ),
                  ),
                  if (block.alert != AlertMode.none) ...<Widget>[
                    const SizedBox(width: 6),
                    Icon(
                      block.alert == AlertMode.alarm
                          ? Icons.alarm_rounded
                          : Icons.notifications_none_rounded,
                      size: 13,
                      color: scheme.onSurfaceVariant,
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
        if (block.subtasks.isNotEmpty) ...<Widget>[
          const SizedBox(width: AppConstants.spaceSm),
          ProgressRing(
            progress: block.progress,
            color: accent,
            size: 36,
            label: '${block.doneCount}/${block.subtasks.length}',
          ),
        ],
      ],
    );
  }
}

/// Pasos del bloque, con su casilla.
///
/// Va sin scroll propio: si no caben todos, el recorte del contenedor los
/// oculta y el bloque completo se abre con un toque.
class _SubtaskList extends ConsumerWidget {
  const _SubtaskList({required this.block, required this.accent});

  final TimeBlock block;
  final Color accent;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ClipRect(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          for (final subtask in block.subtasks)
            _SubtaskRow(
              blockId: block.id,
              subtask: subtask,
              accent: accent,
            ),
        ],
      ),
    );
  }
}

class _SubtaskRow extends ConsumerWidget {
  const _SubtaskRow({
    required this.blockId,
    required this.subtask,
    required this.accent,
  });

  final String blockId;
  final SubTask subtask;
  final Color accent;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scheme = context.colors;

    return Padding(
      padding: const EdgeInsets.only(bottom: 2),
      child: Row(
        children: <Widget>[
          CheckCircle(
            checked: subtask.done,
            size: 18,
            color: accent,
            onTap: () {
              HapticFeedback.selectionClick();
              ref
                  .read(agendaProvider.notifier)
                  .toggleSubTask(blockId, subtask.id);
            },
          ),
          Expanded(
            child: Text(
              subtask.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: context.texts.bodyMedium?.copyWith(
                color: subtask.done
                    ? scheme.onSurfaceVariant
                    : scheme.onSurface,
                decoration: subtask.done ? TextDecoration.lineThrough : null,
                decorationColor: scheme.onSurfaceVariant,
              ),
            ),
          ),
          if (subtask.hasReminder)
            Padding(
              padding: const EdgeInsets.only(left: 6),
              child: Icon(
                subtask.alert == AlertMode.alarm
                    ? Icons.alarm_rounded
                    : Icons.notifications_none_rounded,
                size: 13,
                color: scheme.onSurfaceVariant,
              ),
            ),
        ],
      ),
    );
  }
}
