import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../models/agenda_entry.dart';
import '../../../../utils/date_format.dart';
import '../../../../utils/extensions.dart';
import '../../../../widgets/fade_in.dart';
import '../providers/agenda_providers.dart';
import 'entry_editor_sheet.dart';
import 'quick_task_tile.dart';
import 'time_block_card.dart';

/// Todo lo que viene, agrupado por dia. La vista para planificar.
///
/// No dibuja horas a proposito: aqui lo que importa es la secuencia y poder
/// mirar semanas o meses adelante sin perderse.
class AgendaView extends ConsumerWidget {
  const AgendaView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final all = ref.watch(agendaProvider);
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    // Solo de hoy en adelante: la agenda mira al futuro. Lo pasado se consulta
    // navegando al dia concreto en la vista de dia.
    final upcoming = all.where((e) => !e.day.isBefore(today)).toList();
    final grouped = _groupByDay(upcoming);

    if (grouped.isEmpty) return const _EmptyAgenda();

    final pending = upcoming.where((e) => !e.isComplete).length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(
            AppConstants.spaceMd,
            AppConstants.spaceXs,
            AppConstants.spaceMd,
            AppConstants.spaceMd,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text('Lo que viene', style: context.texts.headlineMedium),
              const SizedBox(height: 2),
              Text(
                pending == 1
                    ? '1 pendiente en ${grouped.length} dia'
                    : '$pending pendientes en ${grouped.length} dias',
                style: context.texts.bodyMedium?.copyWith(
                  color: context.colors.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(
              AppConstants.spaceMd,
              0,
              AppConstants.spaceMd,
              AppConstants.spaceXxl * 2,
            ),
            itemCount: grouped.length,
            itemBuilder: (context, index) {
              final group = grouped[index];
              return FadeIn(
                delay: Duration(milliseconds: 40 * index.clamp(0, 8)),
                child: _DaySection(day: group.day, entries: group.entries),
              );
            },
          ),
        ),
      ],
    );
  }

  List<_DayGroup> _groupByDay(List<AgendaEntry> entries) {
    final map = <DateTime, List<AgendaEntry>>{};
    for (final entry in entries) {
      map.putIfAbsent(entry.day, () => <AgendaEntry>[]).add(entry);
    }

    final days = map.keys.toList()..sort();
    return days.map((day) => _DayGroup(day: day, entries: map[day]!)).toList();
  }
}

class _DayGroup {
  const _DayGroup({required this.day, required this.entries});

  final DateTime day;
  final List<AgendaEntry> entries;
}

class _DaySection extends ConsumerWidget {
  const _DaySection({required this.day, required this.entries});

  final DateTime day;
  final List<AgendaEntry> entries;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scheme = context.colors;
    final pending = entries.where((e) => !e.isComplete).length;

    return Padding(
      padding: const EdgeInsets.only(bottom: AppConstants.spaceLg),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          // Tocar el encabezado salta a ese dia en el riel: es el puente
          // natural entre planificar y ejecutar.
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              ref.read(selectedDayProvider.notifier).select(day);
              ref.read(planningViewProvider.notifier).select(PlanningView.day);
            },
            child: Padding(
              padding: const EdgeInsets.only(
                bottom: AppConstants.spaceSm,
                left: 2,
              ),
              child: Row(
                children: <Widget>[
                  Text(
                    DateNames.relativeDay(day).capitalized,
                    style: context.texts.titleMedium,
                  ),
                  const SizedBox(width: AppConstants.spaceSm),
                  Expanded(
                    child: Container(height: 1, color: scheme.outlineVariant),
                  ),
                  const SizedBox(width: AppConstants.spaceSm),
                  Text(
                    pending == 0 ? 'listo' : '$pending',
                    style: context.texts.labelMedium?.copyWith(
                      color: pending == 0
                          ? scheme.primary
                          : scheme.onSurfaceVariant,
                      letterSpacing: 0,
                    ),
                  ),
                ],
              ),
            ),
          ),
          for (final entry in entries)
            Padding(
              padding: const EdgeInsets.only(bottom: AppConstants.spaceSm),
              child: switch (entry) {
                TimeBlock() => TimeBlockCard(
                    block: entry,
                    onTap: () => showEntryEditor(
                      context,
                      day: day,
                      existing: entry,
                    ),
                  ),
                QuickTask() => QuickTaskTile(
                    task: entry,
                    onTap: () => showEntryEditor(
                      context,
                      day: day,
                      existing: entry,
                    ),
                  ),
              },
            ),
        ],
      ),
    );
  }
}

class _EmptyAgenda extends StatelessWidget {
  const _EmptyAgenda();

  @override
  Widget build(BuildContext context) {
    final scheme = context.colors;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppConstants.spaceXl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              width: 76,
              height: 76,
              decoration: BoxDecoration(
                color: scheme.surfaceContainer,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.event_note_rounded,
                size: 34,
                color: scheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: AppConstants.spaceLg),
            Text('Nada por delante', style: context.texts.titleLarge),
            const SizedBox(height: AppConstants.spaceXs),
            Text(
              'Lo que planifiques va a aparecer aqui,\nordenado dia por dia.',
              textAlign: TextAlign.center,
              style: context.texts.bodyMedium?.copyWith(
                color: scheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
