import 'package:hive_flutter/hive_flutter.dart';

import '../services/logger_service.dart';

/// Nombres de las cajas de Hive.
///
/// Centralizados para que abrir una caja con un nombre mal escrito sea
/// imposible: una caja inexistente se crea vacia en silencio, y ese es
/// exactamente el tipo de error que cuesta horas encontrar.
class HiveBoxes {
  const HiveBoxes._();

  /// Datos generales de la aplicacion.
  static const String app = 'app_box';

  /// Cache de datos remotos.
  static const String cache = 'cache_box';
}

/// Inicializacion de la base de datos local.
///
/// Se guardan mapas planos en vez de objetos con TypeAdapter generado. Es una
/// decision deliberada: evita depender de generacion de codigo y hace que
/// agregar un campo a un modelo no rompa los datos ya guardados en el
/// telefono del usuario.
class HiveSetup {
  const HiveSetup._();

  static Future<void> initialize() async {
    await Hive.initFlutter();

    await Future.wait(<Future<void>>[
      _openBox(HiveBoxes.app),
      _openBox(HiveBoxes.cache),
    ]);

    LoggerService.info('Base de datos local lista.', tag: 'HIVE');
  }

  static Future<void> _openBox(String name) async {
    if (Hive.isBoxOpen(name)) return;
    await Hive.openBox<dynamic>(name);
  }

  /// Cierra todas las cajas. Se llama al terminar la aplicacion.
  static Future<void> dispose() => Hive.close();
}
