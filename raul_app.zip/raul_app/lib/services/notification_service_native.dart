import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

import '../models/agenda_entry.dart';
import '../models/alert_mode.dart';
import 'logger_service.dart';

/// Programa los avisos y las alarmas del sistema.
///
/// Este archivo solo se compila en el telefono. En la web entra en su lugar
/// `notification_service_stub.dart`, que no hace nada. Por eso aqui no hay
/// ninguna comprobacion de plataforma.
class NotificationService {
  NotificationService._();

  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  bool _ready = false;

  /// Zona horaria fija.
  ///
  /// Se deja escrita en vez de detectarla para no sumar otra dependencia: la
  /// aplicacion es de una persona que vive en Chile. Si alguna vez importa
  /// viajar, aqui es donde se cambia.
  static const String _timeZone = 'America/Santiago';

  static const String _channelNotice = 'ruli_avisos';
  static const String _channelAlarm = 'ruli_alarmas';

  /// Cuantos avisos futuros se programan como maximo.
  ///
  /// Android limita las alarmas pendientes por aplicacion. Con noventa dias de
  /// repeticiones por delante conviene cortar: lo que esta a tres meses vista
  /// se reprograma solo la proxima vez que se abra la app.
  static const int _maxScheduled = 60;

  Future<void> initialize() async {
    if (_ready) return;

    try {
      tz_data.initializeTimeZones();
      tz.setLocalLocation(tz.getLocation(_timeZone));

      await _plugin.initialize(
        const InitializationSettings(
          android: AndroidInitializationSettings('@mipmap/ic_launcher'),
        ),
      );

      final android = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

      // Los canales se crean una vez y el usuario puede ajustarlos despues
      // desde los ajustes de Android, que es donde espera encontrarlos.
      await android?.createNotificationChannel(
        const AndroidNotificationChannel(
          _channelNotice,
          'Avisos',
          description: 'Recordatorios discretos de tareas y bloques.',
          importance: Importance.defaultImportance,
        ),
      );
      await android?.createNotificationChannel(
        const AndroidNotificationChannel(
          _channelAlarm,
          'Alarmas',
          description: 'Avisos que suenan hasta que los apagas.',
          importance: Importance.max,
          playSound: true,
          enableVibration: true,
        ),
      );

      _ready = true;
      LoggerService.info('Servicio de avisos listo.', tag: 'AVISOS');
    } catch (error, stackTrace) {
      LoggerService.error(
        'No se pudo iniciar el servicio de avisos.',
        tag: 'AVISOS',
        error: error,
        stackTrace: stackTrace,
      );
    }
  }

  /// Pide los permisos que Android exige desde la version 13.
  ///
  /// Devuelve `false` si el usuario los rechaza, para poder decirselo en vez
  /// de dejar que las alarmas fallen en silencio.
  Future<bool> requestPermissions() async {
    await initialize();

    final android = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    if (android == null) return false;

    final notifications = await android.requestNotificationsPermission();
    // El permiso de alarmas exactas es aparte y puede no estar disponible en
    // versiones antiguas, donde simplemente no hace falta.
    final exact = await android.requestExactAlarmsPermission();

    return (notifications ?? false) || (exact ?? false);
  }

  Future<bool> hasPermission() async {
    await initialize();

    final android = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    return await android?.areNotificationsEnabled() ?? false;
  }

  /// Reprograma todo desde cero a partir de la agenda actual.
  ///
  /// Se borra y se vuelve a programar en vez de intentar llevar la cuenta de
  /// que cambio. Es mas simple y no deja alarmas huerfanas de elementos que
  /// ya se borraron, que es el error clasico de este tipo de sincronizacion.
  Future<void> syncAll(List<AgendaEntry> entries) async {
    await initialize();
    if (!_ready) return;

    try {
      await _plugin.cancelAll();

      final now = DateTime.now();
      final pending = <_PendingAlert>[];

      for (final entry in entries) {
        if (entry.hasReminder && entry.start.isAfter(now)) {
          pending.add(
            _PendingAlert(
              id: _idFor(entry.id),
              title: entry.title,
              body: entry is TimeBlock
                  ? 'Empieza tu bloque'
                  : 'Tienes esto pendiente',
              when: entry.start,
              alert: entry.alert,
            ),
          );
        }

        // Los pasos de un bloque tienen su propio aviso y su propia hora.
        if (entry is TimeBlock) {
          for (final subtask in entry.subtasks) {
            final remindAt = subtask.remindAt;
            if (!subtask.hasReminder || subtask.done) continue;
            if (remindAt == null || !remindAt.isAfter(now)) continue;

            pending.add(
              _PendingAlert(
                id: _idFor('${entry.id}:${subtask.id}'),
                title: subtask.title,
                body: entry.title,
                when: remindAt,
                alert: subtask.alert,
              ),
            );
          }
        }
      }

      pending.sort((a, b) => a.when.compareTo(b.when));

      for (final alert in pending.take(_maxScheduled)) {
        await _schedule(alert);
      }

      LoggerService.info(
        'Programados ${pending.length.clamp(0, _maxScheduled)} avisos.',
        tag: 'AVISOS',
      );
    } catch (error, stackTrace) {
      LoggerService.error(
        'Fallo al programar los avisos.',
        tag: 'AVISOS',
        error: error,
        stackTrace: stackTrace,
      );
    }
  }

  Future<void> _schedule(_PendingAlert alert) async {
    final isAlarm = alert.alert == AlertMode.alarm;

    final details = NotificationDetails(
      android: AndroidNotificationDetails(
        isAlarm ? _channelAlarm : _channelNotice,
        isAlarm ? 'Alarmas' : 'Avisos',
        importance: isAlarm ? Importance.max : Importance.defaultImportance,
        priority: isAlarm ? Priority.high : Priority.defaultPriority,
        // La pantalla completa es lo que hace que una alarma se sienta alarma
        // y no una notificacion mas entre veinte.
        fullScreenIntent: isAlarm,
        category: isAlarm ? AndroidNotificationCategory.alarm : null,
        audioAttributesUsage: isAlarm
            ? AudioAttributesUsage.alarm
            : AudioAttributesUsage.notification,
        enableVibration: true,
        styleInformation: BigTextStyleInformation(alert.body),
      ),
    );

    await _plugin.zonedSchedule(
      alert.id,
      alert.title,
      alert.body,
      tz.TZDateTime.from(alert.when, tz.local),
      details,
      // Las alarmas piden hora exacta incluso con el telefono dormido; los
      // avisos normales aceptan que el sistema los agrupe y ahorre bateria.
      androidScheduleMode: isAlarm
          ? AndroidScheduleMode.exactAllowWhileIdle
          : AndroidScheduleMode.inexactAllowWhileIdle,
    );
  }

  /// Muestra un aviso ahora mismo, para poder comprobar que todo funciona sin
  /// tener que esperar a que llegue la hora de algo.
  Future<void> showTest({bool asAlarm = false}) async {
    await initialize();
    if (!_ready) return;

    await _plugin.show(
      99999,
      asAlarm ? 'Alarma de prueba' : 'Aviso de prueba',
      asAlarm
          ? 'Asi va a sonar cuando pongas una alarma.'
          : 'Asi se va a ver un aviso normal.',
      NotificationDetails(
        android: AndroidNotificationDetails(
          asAlarm ? _channelAlarm : _channelNotice,
          asAlarm ? 'Alarmas' : 'Avisos',
          importance: asAlarm ? Importance.max : Importance.defaultImportance,
          priority: asAlarm ? Priority.high : Priority.defaultPriority,
          audioAttributesUsage: asAlarm
              ? AudioAttributesUsage.alarm
              : AudioAttributesUsage.notification,
        ),
      ),
    );
  }

  /// Convierte un identificador de texto en el entero que exige Android.
  ///
  /// Se recorta el signo porque los negativos no valen como identificador.
  int _idFor(String value) => value.hashCode & 0x7fffffff;
}

class _PendingAlert {
  const _PendingAlert({
    required this.id,
    required this.title,
    required this.body,
    required this.when,
    required this.alert,
  });

  final int id;
  final String title;
  final String body;
  final DateTime when;
  final AlertMode alert;
}
