import '../models/agenda_entry.dart';

/// Version vacia del servicio de avisos, para la web.
///
/// Tiene exactamente la misma forma que la real y no hace nada. Asi el codigo
/// que la usa no necesita preguntar en que plataforma esta corriendo.
class NotificationService {
  NotificationService._();

  static final NotificationService instance = NotificationService._();

  Future<void> initialize() async {}

  Future<bool> requestPermissions() async => false;

  Future<bool> hasPermission() async => false;

  Future<void> syncAll(List<AgendaEntry> entries) async {}

  Future<void> showTest({bool asAlarm = false}) async {}
}
